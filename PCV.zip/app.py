from flask import Flask, render_template, request, jsonify
import math

app = Flask(__name__)

# ---------------- UTILITIES ----------------

def normalize(text):
    return ''.join(filter(str.isalpha, text.upper()))

def get_key_order(key):
    return sorted(range(len(key)), key=lambda k: (key[k], k))

def caesar_encrypt(text, shift):
    return ''.join(chr((ord(c) - 65 + shift) % 26 + 65) for c in text)

def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

# ---------------- FIXED MATRIX COLUMNAR ----------------

def columnar_encrypt_fixed(text, key, rows, cols):
    matrix = [list(text[i:i+cols]) for i in range(0, len(text), cols)]
    order = get_key_order(key)

    ciphertext = ""
    for col in order:
        for r in range(rows):
            ciphertext += matrix[r][col]

    return ciphertext, matrix

def columnar_decrypt_fixed(ciphertext, key, rows, cols):
    order = get_key_order(key)
    matrix = [[""] * cols for _ in range(rows)]

    pointer = 0
    for col in order:
        for r in range(rows):
            matrix[r][col] = ciphertext[pointer]
            pointer += 1

    plaintext = ""
    for r in range(rows):
        for c in range(cols):
            plaintext += matrix[r][c]

    return plaintext, matrix

# ---------------- ROUTES ----------------

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/encrypt", methods=["POST"])
def encrypt():
    data = request.json

    text = normalize(data["text"])
    shift = int(data["shift"])
    key = data["key"].upper()
    rounds = int(data["rounds"])

    cols = len(key)
    rows = math.ceil(len(text) / cols)

    # Pad once only
    text += "X" * (rows * cols - len(text))

    steps = []

    for i in range(1, rounds + 1):
        text = caesar_encrypt(text, shift)
        text, matrix = columnar_encrypt_fixed(text, key, rows, cols)

        steps.append({
            "round": i,
            "matrix": matrix,
            "text": text
        })

    return jsonify({"final": text, "steps": steps})

@app.route("/decrypt", methods=["POST"])
def decrypt():
    data = request.json

    text = normalize(data["text"])
    shift = int(data["shift"])
    key = data["key"].upper()
    rounds = int(data["rounds"])

    cols = len(key)
    rows = len(text) // cols  # fixed from ciphertext

    steps = []

    for i in range(rounds, 0, -1):
        text, matrix = columnar_decrypt_fixed(text, key, rows, cols)
        text = caesar_decrypt(text, shift)

        steps.append({
            "round": i,
            "matrix": matrix,
            "text": text
        })

    # Remove padding once
    text = text.rstrip("X")

    return jsonify({"final": text, "steps": steps})

if __name__ == "__main__":
    app.run(debug=True)