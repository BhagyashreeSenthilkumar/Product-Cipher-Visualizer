let globalSteps = [];
let currentStep = 0;

// ===============================
// SEND REQUEST (Encrypt / Decrypt)
// ===============================
async function sendRequest(url) {

    let text;

    if (url === "/decrypt") {
        text = document.getElementById("finalOutput").innerText.trim();
    } else {
        text = document.getElementById("inputText").value.trim();
    }

    let shift = document.getElementById("shiftKey").value;
    let key = document.getElementById("columnarKey").value;
    let rounds = document.getElementById("rounds").value;

    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, shift, key, rounds })
    });

    const data = await response.json();

    globalSteps = data.steps;
    currentStep = 0;

    document.getElementById("finalOutput").innerText = data.final;

    renderStep();
}

// ===============================
// RENDER STEP
// ===============================
async function renderStep() {

    const stepsContainer = document.getElementById("steps");
    stepsContainer.innerHTML = "";

    if (!globalSteps.length) return;

    const step = globalSteps[currentStep];

    const title = document.createElement("h3");
    title.innerText = "Round " + step.round;
    stepsContainer.appendChild(title);

    renderKeyAnimation();

    let table = document.createElement("table");
    table.className = "matrix";

    step.matrix.forEach(row => {
        let tr = document.createElement("tr");
        row.forEach(cell => {
            let td = document.createElement("td");
            td.innerText = cell;
            tr.appendChild(td);
        });
        table.appendChild(tr);
    });

    stepsContainer.appendChild(table);

    await animateColumnExtraction(table);
}

// ===============================
// NEXT / PREVIOUS
// ===============================
async function nextStep() {
    if (currentStep < globalSteps.length - 1) {
        currentStep++;
        await renderStep();
    }
}

async function prevStep() {
    if (currentStep > 0) {
        currentStep--;
        await renderStep();
    }
}

// ===============================
// COLUMN ANIMATION
// ===============================
async function animateColumnExtraction(table) {

    const cols = table.rows[0].cells.length;
    const rows = table.rows.length;

    for (let c = 0; c < cols; c++) {

        for (let r = 0; r < rows; r++) {
            table.rows[r].cells[c].classList.add("extracting");
        }

        await new Promise(resolve => setTimeout(resolve, 400));

        for (let r = 0; r < rows; r++) {
            table.rows[r].cells[c].classList.remove("extracting");
        }
    }
}

// ===============================
// KEY ANIMATION
// ===============================
function renderKeyAnimation() {

    const key = document.getElementById("columnarKey").value.toUpperCase();
    const stepsContainer = document.getElementById("steps");

    const keyContainer = document.createElement("div");
    keyContainer.style.marginBottom = "10px";
    keyContainer.style.display = "flex";
    keyContainer.style.gap = "10px";

    let keyArray = key.split("");

    let indexedKey = keyArray.map((char, index) => {
        return { char, index };
    });

    let sortedKey = [...indexedKey].sort((a, b) => {
        if (a.char < b.char) return -1;
        if (a.char > b.char) return 1;
        return a.index - b.index;
    });

    sortedKey.forEach((item, sortedIndex) => {

        const box = document.createElement("div");
        box.className = "key-box";

        box.innerHTML = `
            <div>${item.char}</div>
            <small>${sortedIndex + 1}</small>
        `;

        box.style.opacity = "0";
        keyContainer.appendChild(box);

        setTimeout(() => {
            box.style.opacity = "1";
        }, sortedIndex * 300);
    });

    stepsContainer.appendChild(keyContainer);
}

// ===============================
function startEncryption() {
    sendRequest("/encrypt");
}

function startDecryption() {
    sendRequest("/decrypt");
}